﻿Public Class Form1

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        ProgressBar1.Increment(1)
        If ProgressBar1.Value = 100 Then
            PictureBox1.Show()
            Label1.Text = "Complete"
        End If
        Label2.Text = ProgressBar1.Value & ("%")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Timer1.Start()

        'Set the Filter. 
        OpenFileDialog1.Filter = "Bitmap |*.bmp| JPG | *.jpg | GIF | *.gif | PNG | *.png | All Files|*.*"
        'Clear the file name 
        OpenFileDialog1.FileName = ""
        'Show it 
        If OpenFileDialog1.ShowDialog(Me) = DialogResult.OK Then
            'Get the image name 
            Dim img As String = OpenFileDialog1.FileName
            'Create a new Bitmap and display it 
            PictureBox1.Image = System.Drawing.Bitmap.FromFile(img)
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        PictureBox1.Hide()

        Timer1.Stop()
        ProgressBar1.Value = 0
        Label1.Text = "Cleared"
        Label2.Text = "0 %"

    End Sub
End Class